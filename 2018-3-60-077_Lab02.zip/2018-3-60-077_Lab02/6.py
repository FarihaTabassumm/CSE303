s = "Dream big and dare to fail."
w = s.split()
l = []
for i in w:
   l.append(len(i))
print(w)
print(l)