s =  "Practice Problems to Drill List Comprehension in Your Head."
w = s.split()
l = []
for i in w:
   l.append(len(i))
print(w)
print(l)