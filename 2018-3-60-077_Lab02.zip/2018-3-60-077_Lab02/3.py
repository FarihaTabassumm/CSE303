string = "Success is the best Revenge."
print("String is : ", string)
n=len(string)
count=0

for i in range(1,n):
    if(string[i]==' '):
       count+=1 
print("The number of spaces in the string is : ",count)