def rem_vowel(string):
    vowels = ['a','e','i','o','u','A','E','I','O','U']
    result = [letter for letter in string if letter.lower() not in vowels]
    result = ''.join(result)
    print(result)
 
string =  "Practice Problems to Drill List Comprehension in Your Head."
rem_vowel(string)
