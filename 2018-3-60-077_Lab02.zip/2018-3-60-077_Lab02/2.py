x=[]
for i in range (1 ,1001):
    x.append(str(i))
    if x[i-1].find('6')!=-1:
     print(x[i-1])